package com.revshop.models;

import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Map<Product, Integer> products = new HashMap<>();

    // Add product to cart (or update quantity if already present)
    public void addProduct(Product product, int quantity) {
        products.put(product, products.getOrDefault(product, 0) + quantity);
    }

    // Remove product from cart
    public void removeProduct(Product product) {
        products.remove(product);
    }

    // Update product quantity in cart
    public void updateProductQuantity(Product product, int quantity) {
        if (products.containsKey(product)) {
            if (quantity > 0) {
                // Update the quantity
                products.put(product, quantity);
            } else {
                // Remove product if quantity is 0 or negative
                removeProduct(product);  
            }
        }
    }

    // Get total price of all products in the cart
    public double getTotalPrice() {
        return products.entrySet().stream()
                .mapToDouble(entry -> entry.getKey().getPrice() * entry.getValue())
                .sum();
    }

    // Get all products and their quantities in the cart
    public Map<Product, Integer> getProducts() {
        return products;
    }

    // Check if the cart is empty
    public boolean isEmpty() {
        return products.isEmpty();
    }

    // Clear the cart
    public void clearCart() {
        products.clear();
    }
}
