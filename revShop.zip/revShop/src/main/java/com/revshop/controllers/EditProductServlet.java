package com.revshop.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revshop.dao.ProductDAO;
import com.revshop.models.Product;

public class EditProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve product details from the form
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        String image = request.getParameter("image");
        int quantity=Integer.parseInt(request.getParameter("quantity"));

        // Create a product object with the new details
        Product product = new Product();
        product.setId(id);
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setImage(image);
        product.setQuantity(quantity);

        // Call DAO to update product in the database
        ProductDAO productDAO = new ProductDAO(null);
        productDAO.updateProduct(product);

        // Redirect to the product list page
        response.sendRedirect("list_products.jsp");
    }
}
