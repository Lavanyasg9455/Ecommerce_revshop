package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revshop.dao.LoginDAO;
import com.revshop.dao.UserDAO;
import com.revshop.models.Login;
import com.revshop.models.User;

public class BuyerLoginServlet extends HttpServlet {
    private UserDAO userDAO;
    private LoginDAO loginDAO;

    @Override
    public void init() throws ServletException {
        Connection conn = (Connection) getServletContext().getAttribute("DBConnection");
        if (conn != null) {
            userDAO = new UserDAO(conn);
            loginDAO = new LoginDAO(conn);  // Initialize the LoginDAO to save login details
        } else {
            throw new ServletException("DB connection not initialized");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = null;
        try {
            user = userDAO.validateUser(email, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        if (user != null && "buyer".equals(user.getRole())) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userEmail", user.getEmail());

            // Save login details for buyers
            try {
                Login login = new Login(email, password);
                loginDAO.saveLogin(login);
            } catch (SQLException e) {
                e.printStackTrace();  // Handle exception
            }

            // Redirect to buyer homepage
            response.sendRedirect("homePage.jsp");
        } else {
            request.setAttribute("errorMessage", "Invalid email or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
