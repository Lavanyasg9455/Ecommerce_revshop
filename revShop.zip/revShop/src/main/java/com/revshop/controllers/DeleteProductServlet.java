package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revshop.dao.ProductDAO;
import com.revshop.utils.DBConnection; // Import your DB connection utility

public class DeleteProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        // Get a connection from your DBConnection utility
        try (Connection connection = DBConnection.getConnection()) { // Ensure you have this utility
            // Call DAO to delete product from the database
            ProductDAO productDAO = new ProductDAO(connection);
            productDAO.deleteProduct(id);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Optionally, handle error or redirect to an error page
        }

        // Redirect to the product list page
        response.sendRedirect("products");
    }
}
