package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revshop.dao.ProductDAO;
import com.revshop.models.Product;

@WebServlet("/productList")
public class ProductListServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        

		 System.out.println("ProductServlet: doGet method invoked.");
	    Connection dbConnection = (Connection) getServletContext().getAttribute("DBConnection");
	    
	    // Check if the DB connection is available
	    if (dbConnection == null) {
	        System.out.println("DBConnection is null.");
	        response.getWriter().write("Database connection is not available.");
	        return;
	    } else {
	        System.out.println("DBConnection is available.");
	    }

	    ProductDAO productDAO = new ProductDAO(dbConnection);
	    List<Product> productList = productDAO.getAllProducts();
        
        // Set the product list as an attribute to pass to JSP
        request.setAttribute("productList", productList);
        
        // Forward the request to productList.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("/productList.jsp");
        dispatcher.forward(request, response);
    }
}
