package com.revshop.controllers;

import com.revshop.dao.OrderDAO;
import com.revshop.models.Order;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

public class OrderHistoryServlet extends HttpServlet {
    private OrderDAO orderDAO;

    @Override
    public void init() throws ServletException {
        // Initialize OrderDAO with the database connection from the servlet context
        orderDAO = new OrderDAO((Connection) getServletContext().getAttribute("DBConnection"));
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        // Retrieve userId from session
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId != null) {
            // Get orders for the logged-in user
            List<Order> orders = orderDAO.getOrdersByUserId(userId);
            request.setAttribute("orders", orders);
            // Forward to order history JSP
            request.getRequestDispatcher("orderHistory.jsp").forward(request, response);
        } else {
            // Handle the case where userId is not available in session (e.g., redirect to login)
            response.sendRedirect("login.jsp"); // Adjust this to your login page
        }
    }
}
