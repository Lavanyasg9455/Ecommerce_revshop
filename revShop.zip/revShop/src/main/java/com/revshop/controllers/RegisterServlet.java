// com/revshop/controllers/RegisterServlet.java
package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revshop.dao.UserDAO;
import com.revshop.models.User;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String role = request.getParameter("role");

        Connection connection = (Connection) getServletContext().getAttribute("DBConnection");
        UserDAO userDAO = new UserDAO(connection);
        User user = new User(email, password, name, role);

        try {
            try {
				if (userDAO.registerUser(user)) {
				    // Redirect based on role after successful registration
				    if ("seller".equals(role)) {
				        response.sendRedirect("seller_login.jsp"); // Redirect to seller's add product page
				    } else {
				        response.sendRedirect("login.jsp"); // Redirect to buyer's login page
				    }
				} else {
				    response.sendRedirect("register.jsp?error=Registration Failed");
				}
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=Registration Failed");
        }
    }
}
