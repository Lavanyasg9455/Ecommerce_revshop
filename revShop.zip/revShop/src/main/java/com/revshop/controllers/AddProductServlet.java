package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revshop.dao.ProductDAO;
import com.revshop.models.Product;
import com.revshop.utils.DBConnection;

public class AddProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the seller ID from the session
        HttpSession session = request.getSession();
        Integer sellerId = (Integer) session.getAttribute("loggedInSellerId");
        System.out.println("Session attributes: " + Collections.list(session.getAttributeNames()));

        // Check if the seller ID is found in the session
        if (sellerId == null) {
            response.getWriter().write("Seller ID is not found in session.");
            return; // Exit the method if seller ID is not found
        }

        System.out.println("Seller ID from session: " + sellerId);

        // Retrieve product details from the form
        String name = request.getParameter("name");
        String description = request.getParameter("description");

        double price;
        try {
            price = Double.parseDouble(request.getParameter("price"));
        } catch (NumberFormatException e) {
            response.getWriter().write("Invalid price format.");
            return; // Exit the method
        }

        String image = request.getParameter("image");

        int quantity = 0; // Default value
        String quantityStr = request.getParameter("quantity");
        if (quantityStr != null && !quantityStr.isEmpty()) {
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                System.err.println("Invalid quantity: " + quantityStr);
                response.getWriter().write("Invalid quantity format.");
                return; // Exit the method
            }
        }

        // Create a new product object
        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setImage(image);
        product.setQuantity(quantity);  // Set quantity
        product.setSellerId(sellerId);  // Set seller ID from the session

        // Check if the seller exists before adding the product
        if (!isSellerExists(sellerId)) {
            response.getWriter().write("Invalid seller ID.");
            return; // Exit the method if the seller ID is not valid
        }

        // Call DAO to add product to the database
        try (Connection connection = DBConnection.getConnection()) {
            ProductDAO productDAO = new ProductDAO(connection);
            boolean isProductAdded = productDAO.addProduct(product);

            if (isProductAdded) {
                // Redirect to the product list page
            	 response.sendRedirect("products");
            } else {
                // Handle product addition failure (e.g., show error message)
                response.getWriter().write("Failed to add product.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().write("Database error: " + e.getMessage());
        }
    }

    // Method to check if the seller exists in the users table
    private boolean isSellerExists(int sellerId) {
        String query = "SELECT COUNT(*) FROM users WHERE id = ? AND role = 'seller'";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return true; // Seller exists
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false; // Seller does not exist or an error occurred
    }
}
