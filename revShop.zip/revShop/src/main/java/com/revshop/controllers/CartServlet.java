package com.revshop.controllers;

import com.revshop.dao.ProductDAO;
import com.revshop.models.Cart;
import com.revshop.models.Product;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;

public class CartServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        // Initialize ProductDAO with the DB connection
        productDAO = new ProductDAO((Connection) getServletContext().getAttribute("DBConnection"));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        // If the cart is not yet created, initialize it
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        // Retrieve productId and quantity from the request
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Get the product from the DAO using productId
        Product product = productDAO.getProductById(productId);

        if (product != null && quantity > 0) {
            // Check if the product is already in the cart
            if (cart.getProducts().containsKey(product)) {
                // Update the quantity if the product is already in the cart
                cart.updateProductQuantity(product, cart.getProducts().get(product) + quantity); // Increment the quantity
            } else {
                // Add the product to the cart with the specified quantity
                cart.addProduct(product, quantity);
            }
        }

        // Update the session with the modified cart
        session.setAttribute("cart", cart);

        // Redirect to the cart page to display the updated cart
        response.sendRedirect("cart.jsp");
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward the request to the cart.jsp page
        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }
}
