package com.revshop.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revshop.dao.OrderDAO;
import com.revshop.models.Cart;
import com.revshop.models.Order;

public class CheckoutServlet extends HttpServlet {
    private OrderDAO orderDAO;

    @Override
    public void init() throws ServletException {
        // Initialize OrderDAO with database connection
        Connection dbConnection = (Connection) getServletContext().getAttribute("DBConnection");
        if (dbConnection == null) {
            throw new ServletException("Database connection not available.");
        }
        orderDAO = new OrderDAO(dbConnection);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        // Check if the cart is empty
        if (cart == null || cart.getProducts().isEmpty()) {
            response.sendRedirect("cart.jsp"); // Redirect to cart if empty
            return;
        }

        // Get user ID from session
        Integer userId = (Integer) session.getAttribute("userId");  // Handle possible null userId
        if (userId == null) {
            response.sendRedirect("login.jsp?error=Please login to complete the purchase");
            return;
        }

        String shippingAddress = request.getParameter("address");
        String paymentMethod = request.getParameter("paymentMethod");

        // Server-side validation
        if (shippingAddress == null || shippingAddress.trim().isEmpty() || paymentMethod == null || paymentMethod.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Shipping address and payment method are required.");
            request.getRequestDispatcher("checkout.jsp").forward(request, response);
            return;
        }

        // Create an order object and set its properties
        Order order = new Order();
        order.setUserId(userId);
        order.setTotalAmount(cart.getTotalPrice());
        order.setShippingAddress(shippingAddress);
        order.setPaymentMethod(paymentMethod);
        order.setStatus("Pending"); // Set the initial status

        try {
            // Save the order to the database
            orderDAO.saveOrder(order);
        } catch (SQLException e) {
            // Log the error and display a user-friendly message
            e.printStackTrace();
            request.setAttribute("errorMessage", "There was an error processing your order.");
            request.getRequestDispatcher("checkout.jsp").forward(request, response);
            return;
        }

        // Clear the cart after the order is placed
        session.removeAttribute("cart");

        // Redirect to a confirmation page
        response.sendRedirect("order_confirmation.jsp");
    }
}
