package com.revshop.listeners;

import com.revshop.utils.DBConnection;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.sql.Connection;
import java.sql.SQLException;

@WebListener
public class DBConnectionListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        try {
            // Create a new DB connection
            Connection connection = DBConnection.getConnection();
            // Set the connection in the servlet context
            ServletContext ctx = sce.getServletContext();
            ctx.setAttribute("DBConnection", connection);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void contextDestroyed(ServletContextEvent sce) {
        // Clean up the connection if necessary
        Connection con = (Connection) sce.getServletContext().getAttribute("DBConnection");
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
