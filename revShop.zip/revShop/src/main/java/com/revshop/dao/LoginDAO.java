package com.revshop.dao;

import com.revshop.models.Login;
import com.revshop.models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LoginDAO {
    
    private Connection connection;

    public LoginDAO(Connection connection) {
        this.connection = connection;
    }


    public boolean saveLogin(Login login) throws SQLException {
    	if (connection == null) {
            throw new SQLException("Database connection is not available.");
        }
        String sql = "INSERT INTO login (email, password) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, login.getEmail());
            stmt.setString(2, login.getPassword());
            int rowsAffected = stmt.executeUpdate();
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
