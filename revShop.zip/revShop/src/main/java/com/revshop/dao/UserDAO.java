package com.revshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.revshop.models.User;

public class UserDAO {
    // Existing field for connection
    private Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }


	// UPDATED registerUser method (Removed DBConnection.getConnection())
    public boolean registerUser(User user) throws ClassNotFoundException, SQLException {
    	if (connection == null) {
            throw new SQLException("Database connection is not available.");
        }
        String query = "INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = connection.prepareStatement(query)) {  // <--- Use the 'connection' field here
            pst.setString(1, user.getEmail());
            pst.setString(2, user.getPassword());
            pst.setString(3, user.getName());
            pst.setString(4, user.getRole());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // UPDATED validateUser method (Removed DBConnection.getConnection())
    public User validateUser(String email, String password) throws ClassNotFoundException, SQLException {
    	if (connection == null) {
            throw new SQLException("Database connection is not available.");
        }
        String query = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {  // <--- Use the 'connection' field here
            pst.setString(1, email);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return new User(rs.getInt("id"), rs.getString("email"), rs.getString("password"), rs.getString("name"), rs.getString("role"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
