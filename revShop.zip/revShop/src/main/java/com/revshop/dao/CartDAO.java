package com.revshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.revshop.models.Cart;
import com.revshop.models.Product;

public class CartDAO {
    private Connection connection;

    public CartDAO(Connection connection) {
        this.connection = connection;
    }

    // Save cart items to database (for session persistence)
    public void saveCart(int userId, Cart cart) throws SQLException {
        String deleteQuery = "DELETE FROM carts WHERE user_id = ?";
        String insertQuery = "INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)";

        // Remove previous cart
        try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
            deleteStatement.setInt(1, userId);
            deleteStatement.executeUpdate();
        }

        // Add new cart items
        try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
            for (Product product : cart.getProducts().keySet()) {
                insertStatement.setInt(1, userId);
                insertStatement.setInt(2, product.getId());
                insertStatement.setInt(3, cart.getProducts().get(product));
                insertStatement.executeUpdate();
            }
        }
    }

 // Load cart items from database
    public Cart loadCart(int userId) throws SQLException {
        Cart cart = new Cart();
        String query = "SELECT p.id, p.name, p.description, p.price, p.image_url, c.quantity " +
                       "FROM products p INNER JOIN carts c ON p.id = c.product_id WHERE c.user_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("description"),
                        resultSet.getDouble("price"),
                        resultSet.getString("image_url"),
                        resultSet.getInt("quantity"),  // Assuming you want to set quantity here
                        -1 // or some default value for sellerId
                    );
                    cart.addProduct(product, resultSet.getInt("quantity"));
                }
            }
        }
        return cart;
    }

}

