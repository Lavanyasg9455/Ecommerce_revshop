package com.revshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revshop.models.Product;

public class ProductDAO {
    private Connection connection;

    public ProductDAO(Connection connection) {
        this.connection = connection;
    }



	// Retrieve all products from the database
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM products";
        
        try (Statement statement = connection.createStatement(); 
             ResultSet resultSet = statement.executeQuery(query)) {
        	
        	System.out.println("Executing query: " + query);
            
            while (resultSet.next()) {
                Product product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setName(resultSet.getString("name"));
                product.setDescription(resultSet.getString("description"));
                product.setPrice(resultSet.getDouble("price"));
                product.setImage(resultSet.getString("image"));
                product.setQuantity(resultSet.getInt("quantity")); 
                product.setSellerId(resultSet.getInt("seller_id"));

                productList.add(product);
            }
            
            System.out.println("Number of products retrieved: " + productList.size());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }

    // Add a new product to the database (for Sellers)
    public boolean addProduct(Product product) throws SQLException {
    	if (connection == null) {
            throw new SQLException("Database connection is not available.");
        }
    	
    	 // Print product details before insertion
        System.out.println("Adding Product: " + product.getName() + ", Seller ID: " + product.getSellerId());
        
        String query = "INSERT INTO products (name, description, price, image,quantity,seller_id) VALUES (?, ?, ?, ? ,? ,?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getDescription());
            statement.setDouble(3, product.getPrice());
            statement.setString(4, product.getImage());
            statement.setInt(5, product.getQuantity());  // Insert quantity
            statement.setInt(6, product.getSellerId());  // Insert seller_id
            int rowsInserted = statement.executeUpdate();
            
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update product information (for inventory management)
    public boolean updateProduct(Product product) {
        String query = "UPDATE products SET name = ?, description = ?, price = ?, image = ? ,quantity = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getDescription());
            statement.setDouble(3, product.getPrice());
            statement.setString(4, product.getImage());
            statement.setInt(5, product.getQuantity());
            statement.setInt(6, product.getId());
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a product by its ID (for sellers to remove products from inventory)
    public boolean deleteProduct(int productId) {
        String query = "DELETE FROM products WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, productId);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

 // Retrieve a product by its ID
    public Product getProductById(int productId) {
        String query = "SELECT * FROM products WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("description"),
                        resultSet.getDouble("price"),
                        resultSet.getString("image"),
                        resultSet.getInt("quantity"), // Add quantity here
                        resultSet.getInt("seller_id")  // Include sellerId here
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;  // Return null if no product found
    }



    // Check product inventory (fetch low stock)
    public List<Product> getLowStockProducts(int threshold) {
    	
        List<Product> lowStockProducts = new ArrayList<>();
        String query = "SELECT * FROM products WHERE stock < ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, threshold);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Product product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setName(resultSet.getString("name"));
                product.setDescription(resultSet.getString("description"));
                product.setPrice(resultSet.getDouble("price"));
                product.setImage(resultSet.getString("image"));
                product.setQuantity(resultSet.getInt("quantity"));

                lowStockProducts.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lowStockProducts;
    }
}
